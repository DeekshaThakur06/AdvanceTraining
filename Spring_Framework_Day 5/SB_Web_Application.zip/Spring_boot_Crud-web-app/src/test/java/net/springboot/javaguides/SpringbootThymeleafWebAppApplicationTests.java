package net.springboot.javaguides;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootThymeleafWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
